package com.yhl.oauth2.entity;

import com.yhl.base.baseEntity.BaseEntity;

public class MyUser extends BaseEntity<String> {
}
