package com.yhl.oauth2.service;

import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

public interface MyAuthorizationServerTokenServices extends AuthorizationServerTokenServices {
}
