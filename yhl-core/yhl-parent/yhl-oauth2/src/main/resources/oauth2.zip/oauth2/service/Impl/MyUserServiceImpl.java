package com.yhl.oauth2.service.Impl;

import com.yhl.base.baseService.impl.BaseServiceImpl;
import com.yhl.oauth2.entity.MyUser;

public class MyUserServiceImpl extends BaseServiceImpl<MyUser,String> {
}
