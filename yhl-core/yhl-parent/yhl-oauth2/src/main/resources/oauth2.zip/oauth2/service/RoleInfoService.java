package com.yhl.oauth2.service;

import com.yhl.base.baseService.BaseService;
import com.yhl.oauth2.entity.RoleInfo;

public interface RoleInfoService extends BaseService<RoleInfo,String> {
}
