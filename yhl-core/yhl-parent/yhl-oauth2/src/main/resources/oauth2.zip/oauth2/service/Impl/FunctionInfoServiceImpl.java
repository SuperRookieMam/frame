package com.yhl.oauth2.service.Impl;

import com.yhl.base.baseService.impl.BaseServiceImpl;
import com.yhl.oauth2.entity.FunctionInfo;
import com.yhl.oauth2.service.FunctionInfoService;
import org.springframework.stereotype.Service;

@Service
public class FunctionInfoServiceImpl extends BaseServiceImpl<FunctionInfo,String> implements FunctionInfoService {
}
