package com.yhl.oauth2.service;

import com.yhl.base.baseService.BaseService;
import com.yhl.oauth2.entity.MyUser;

public interface MyUserService extends BaseService<MyUser,String> {
}
