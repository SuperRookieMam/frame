package com.yhl.oauth2.service;

import com.yhl.base.baseService.BaseService;
import com.yhl.oauth2.entity.FunctionInfo;

public interface FunctionInfoService extends BaseService<FunctionInfo,String> {
}
