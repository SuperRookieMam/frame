package com.yhl.oauth2;

public class OauthApplication {
}
