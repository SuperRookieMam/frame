package com.yhl.oauth2.service.Impl;

import com.yhl.base.baseService.impl.BaseServiceImpl;
import com.yhl.oauth2.entity.RoleInfo;
import com.yhl.oauth2.service.RoleInfoService;
import org.springframework.stereotype.Service;

@Service
public class RoleInfoServiceImpl extends BaseServiceImpl<RoleInfo,String> implements RoleInfoService {


}
