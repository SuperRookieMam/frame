package com.yhl.oauth2.service.Impl;

import com.yhl.base.baseService.impl.BaseServiceImpl;
import com.yhl.oauth2.entity.UserFunction;
import com.yhl.oauth2.service.UserFunctionService;
import org.springframework.stereotype.Service;

@Service
public class UserFunctionServiceImpl extends BaseServiceImpl<UserFunction,String> implements UserFunctionService {

}
