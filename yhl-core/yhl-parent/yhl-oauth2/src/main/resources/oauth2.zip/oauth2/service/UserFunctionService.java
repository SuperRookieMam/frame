package com.yhl.oauth2.service;

import com.yhl.base.baseService.BaseService;
import com.yhl.oauth2.entity.UserFunction;

public interface UserFunctionService extends BaseService<UserFunction,String> {
}
